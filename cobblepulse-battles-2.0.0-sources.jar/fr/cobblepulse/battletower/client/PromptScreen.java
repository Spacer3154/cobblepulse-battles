package fr.cobblepulse.battletower.client;

import com.google.gson.JsonObject;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

/**
 * Fenetre de saisie (prix, nom, duree, commande...) affichee par-dessus un menu CobblePulse. Valider envoie la reponse
 * au serveur ; Annuler ou Echap revient au menu.
 */
public final class PromptScreen extends class_437 implements Overlay {
    class_437 parent;
    private final class_2561 prompt;
    private class_342 box;
    private int bx, by, bw, bh;

    PromptScreen(class_437 parent, class_2561 prompt) {
        super(class_2561.method_43470("Saisie"));
        this.parent = parent;
        this.prompt = prompt;
    }

    @Override
    protected void method_25426() {
        if (parent != null) parent.method_25423(field_22787, field_22789, field_22790);
        bw = Math.min(340, field_22789 - 40);
        List<class_5481> lines = field_22793.method_1728(prompt, bw - 24);
        bh = 22 + Math.min(4, lines.size()) * 10 + 60;
        bx = (field_22789 - bw) / 2;
        by = (field_22790 - bh) / 2;
        String old = box == null ? "" : box.method_1882();
        int fy = by + 16 + Math.min(4, lines.size()) * 10 + 6;
        box = new class_342(field_22793, bx + 12, fy, bw - 24, 18, class_2561.method_43470("Réponse"));
        box.method_1880(256);
        box.method_1852(old);
        method_37063(box);
        method_48265(box);
        int half = (bw - 24 - 6) / 2;
        method_37063(class_4185.method_46430(class_2561.method_43470("Valider"), b -> submit()).method_46434(bx + 12, fy + 26, half, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Annuler"), b -> method_25419()).method_46434(bx + 18 + half, fy + 26, half, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float pt) {
        if (parent != null) parent.method_25394(g, -1, -1, pt);
        else method_52752(g);
        g.method_51448().method_22903();
        g.method_51448().method_46416(0, 0, 400);
        g.method_25294(0, 0, field_22789, field_22790, 0x88000000);
        Ui.panel(g, bx, by, bw, bh, Ui.PANEL, Ui.ACCENT);
        List<class_5481> lines = field_22793.method_1728(prompt, bw - 24);
        for (int i = 0; i < Math.min(4, lines.size()); i++) g.method_51430(field_22793, lines.get(i), bx + 12, by + 12 + i * 10, Ui.TEXT, false);
        super.method_25394(g, mx, my, pt);
        g.method_51448().method_22909();
    }

    @Override
    public void method_25420(class_332 g, int mx, int my, float pt) {
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            submit();
            return true;
        }
        return super.method_25404(key, scan, mods);
    }

    void submit() {
        submit(box == null ? "" : box.method_1882());
    }

    void submit(String text) {
        JsonObject o = new JsonObject();
        o.addProperty("text", text);
        Ui.send("prompt_answer", o);
        if (field_22787 != null) field_22787.method_1507(null);
    }

    void setText(String s) {
        if (box != null) box.method_1852(s);
    }

    class_2561 prompt() {
        return prompt;
    }

    /** Annuler : retour au menu (toujours valide cote serveur). */
    @Override
    public void method_25419() {
        JsonObject o = new JsonObject();
        o.addProperty("cancel", true);
        Ui.send("prompt_answer", o);
        if (field_22787 != null) field_22787.method_1507(parent instanceof MenuScreen ? parent : null);
    }

    @Override
    public class_437 parentScreen() {
        return parent;
    }

    @Override
    public void setParentScreen(class_437 s) {
        parent = s;
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
