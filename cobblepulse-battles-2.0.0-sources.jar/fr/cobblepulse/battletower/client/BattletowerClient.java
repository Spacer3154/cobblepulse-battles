package fr.cobblepulse.battletower.client;

import fr.cobblepulse.battletower.Battletower;
import fr.cobblepulse.battletower.core.Json;
import fr.cobblepulse.battletower.data.TrainerSpec;
import fr.cobblepulse.battletower.net.Payloads;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;

/** Cote client : editeur graphique des dresseurs et apercu 3D des skins. */
public final class BattletowerClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(Payloads.OpenEditor.TYPE, (payload, ctx) -> ctx.client().execute(() -> {
            TrainerSpec spec;
            try {
                spec = Json.GSON.fromJson(payload.trainerJson(), TrainerSpec.class);
            } catch (Exception e) {
                spec = new TrainerSpec();
            }
            class_310.method_1551().method_1507(new TrainerEditorScreen(payload.kind(), payload.id(), spec, payload.metaJson()));
        }));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.EditorResult.TYPE, (payload, ctx) -> ctx.client().execute(() -> {
            if (class_310.method_1551().field_1755 instanceof TrainerEditorScreen s) s.onResult(payload);
        }));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.SkinData.TYPE, (payload, ctx) -> ctx.client().execute(() -> SkinCache.receive(payload)));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Data.TYPE, (payload, ctx) -> ctx.client().execute(() -> receive(payload.kind(), payload.json())));
        // les menus couvrent le chat : les messages du serveur s'affichent dans l'ecran ouvert
        net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            class_310 mc = class_310.method_1551();
            if (mc.field_1755 instanceof MenuScreen m) m.notice(message);
            else if (mc.field_1755 instanceof Overlay ov && ov.parentScreen() instanceof MenuScreen m) m.notice(message);
        });
        if ("true".equals(System.getProperty("cobblepulse_battles.clienttest"))) ClientSelfTest.install();
        Battletower.LOG.info("[Battles] Client initialise");
    }

    /** Ecrans pilotes par le serveur : handlers supplementaires (Ranked...). */
    private static final java.util.Map<String, java.util.function.Consumer<com.google.gson.JsonObject>> KINDS = new java.util.HashMap<>();

    public static void on(String kind, java.util.function.Consumer<com.google.gson.JsonObject> handler) {
        KINDS.put(kind, handler);
    }

    static void showMenu(class_310 mc, com.google.gson.JsonObject o) {
        if (mc.field_1755 instanceof MenuScreen m) m.update(o);
        else if (mc.field_1755 instanceof Overlay ov) {
            if (ov.parentScreen() instanceof MenuScreen m) m.update(o);
            else ov.setParentScreen(new MenuScreen(o));
        } else mc.method_1507(new MenuScreen(o));
    }

    private static net.minecraft.class_2561 json(class_310 mc, String raw) {
        try {
            var conn = mc.method_1562();
            var c = conn == null ? null : net.minecraft.class_2561.class_2562.method_10877(raw, conn.method_29091());
            if (c != null) return c;
        } catch (Exception ignored) {
        }
        return net.minecraft.class_2561.method_43470(raw);
    }

    static void receive(String kind, String raw) {
        class_310 mc = class_310.method_1551();
        com.google.gson.JsonObject o;
        try {
            o = com.google.gson.JsonParser.parseString(raw).getAsJsonObject();
        } catch (Exception e) {
            Battletower.LOG.warn("[Battles] Donnees illisibles ({}) : {}", kind, e.toString());
            return;
        }
        switch (kind) {
            case "menu" -> showMenu(mc, o);
            case "menu_close" -> {
                if (mc.field_1755 instanceof MenuScreen || mc.field_1755 instanceof Overlay) mc.method_1507(null);
            }
            case "prompt" -> {
                net.minecraft.class_437 parent = mc.field_1755 instanceof MenuScreen ? mc.field_1755 : null;
                mc.method_1507(new PromptScreen(parent, json(mc, Ui.str(o, "text", ""))));
            }
            case "pick" -> {
                net.minecraft.class_437 parent = mc.field_1755 instanceof MenuScreen ? mc.field_1755 : null;
                mc.method_1507(new ItemPickerScreen(parent, json(mc, Ui.str(o, "title", "")), Ui.str(o, "value", "")));
            }
            default -> {
                var h = KINDS.get(kind);
                if (h != null) h.accept(o);
            }
        }
    }
}
