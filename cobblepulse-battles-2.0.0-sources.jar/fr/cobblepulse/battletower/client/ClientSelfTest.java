package fr.cobblepulse.battletower.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import fr.cobblepulse.battletower.Battletower;
import fr.cobblepulse.battletower.core.Json;
import fr.cobblepulse.battletower.data.ShowdownFormat;
import fr.cobblepulse.battletower.data.TrainerSpec;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_442;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/** Auto-test visuel (CI) : ouvre l'editeur sur l'ecran titre, capture chaque onglet puis ferme le jeu. */
final class ClientSelfTest {
    private static int ticks;
    private static int start = -1;
    private static TrainerEditorScreen screen;

    private ClientSelfTest() {}

    private static int connectedAt = -1;

    static void install() {
        ClientTickEvents.END_CLIENT_TICK.register(ClientSelfTest::tick);
        // Test de bout en bout : le serveur ouvre ses ecrans puis demande une capture
        BattletowerClient.on("selftest", o -> {
            class_310 mc = class_310.method_1551();
            if (o.has("shot")) {
                String name = o.get("shot").getAsString();
                Battletower.LOG.info("[Battletower][clienttest] capture {} (ecran {})", name, mc.field_1755 == null ? "aucun" : mc.field_1755.getClass().getSimpleName());
                shot(mc, name);
            }
            if (o.has("done")) {
                Battletower.LOG.info("[Battletower][clienttest] CLIENT SERVER TEST DONE");
                mc.method_1592();
            }
        });
    }

    private static void shot(class_310 mc, String name) {
        class_318.method_22690(mc.field_1697, name + ".png", mc.method_1522(), c -> Battletower.LOG.info("[Battletower][clienttest] {}", c.getString()));
    }

    private static String meta() {
        JsonObject o = new JsonObject();
        o.addProperty("title", "Étage 12 - Éditeur du dresseur");
        JsonArray skins = new JsonArray();
        try (InputStream in = ClientSelfTest.class.getResourceAsStream("/assets/cobblepulse_battletower/textures/entity/npc/index.txt")) {
            if (in != null) {
                BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                String line;
                while ((line = r.readLine()) != null) {
                    if (line.isBlank() || line.startsWith("#")) continue;
                    String[] p = line.split("\\|");
                    JsonObject s = new JsonObject();
                    s.addProperty("ref", "builtin:" + p[0].trim());
                    s.addProperty("label", p.length > 2 ? p[2].trim() : p[0].trim());
                    s.addProperty("slim", p.length > 1 && "slim".equalsIgnoreCase(p[1].trim()));
                    skins.add(s);
                }
            }
        } catch (Exception ignored) {
        }
        o.add("skins", skins);
        JsonArray tiers = new JsonArray();
        for (String[] t : new String[][]{{"ag", "AG (Anything Goes)"}, {"ou", "OU (OverUsed)"}, {"monotype", "Monotype"}, {"lc", "Little Cup"}}) {
            JsonObject j = new JsonObject();
            j.addProperty("id", t[0]);
            j.addProperty("name", t[1]);
            tiers.add(j);
        }
        o.add("tiers", tiers);
        return Json.COMPACT.toJson(o);
    }

    private static void tick(class_310 mc) {
        ticks++;
        if (ticks % 200 == 0) {
            Battletower.LOG.info("[Battletower][clienttest] tick {} ecran={} overlay={}", ticks,
                    mc.field_1755 == null ? "aucun" : mc.field_1755.getClass().getSimpleName(), mc.method_18506() != null);
        }
        if (start < 0) {
            // Ecran titre, ou tout autre ecran d'accueil (premier lancement : accessibilite, avertissements...)
            if (mc.method_18506() == null && ((mc.field_1755 instanceof class_442 && ticks > 60) || (mc.field_1755 != null && ticks > 400))) {
                start = ticks;
                Battletower.LOG.info("[Battletower][clienttest] debut sur {}", mc.field_1755.getClass().getSimpleName());
            } else if (ticks > 6000) {
                Battletower.LOG.error("[Battletower][clienttest] ecran titre jamais atteint");
                mc.method_1592();
            }
            return;
        }
        int t = ticks - start;
        try {
            if (t == 20) {
                TrainerSpec spec = new TrainerSpec();
                spec.name = "Lysandre";
                spec.title = "As";
                spec.ai = "HARD";
                spec.tier = "ou";
                spec.weather = "rain";
                spec.levelScale = 50;
                spec.skin = "builtin:veteran";
                spec.team.addAll(ShowdownFormat.parse("Garchomp @ Life Orb\nAbility: Rough Skin\nLevel: 50\nTera Type: Steel\n"
                        + "EVs: 252 Atk / 4 SpD / 252 Spe\nJolly Nature\n- Earthquake\n- Dragon Claw\n- Swords Dance\n- Stone Edge\n\n"
                        + "Rotom-Wash @ Leftovers\nAbility: Levitate\nLevel: 50\nEVs: 252 HP / 252 Def / 4 SpA\nBold Nature\n- Hydro Pump\n- Volt Switch\n"
                        + "- Will-O-Wisp\n- Protect\n"));
                screen = new TrainerEditorScreen("floor", "12", spec, meta());
                mc.method_1507(screen);
            } else if (t == 50) {
                shot(mc, "bt_editor_general");
                screen.setTab(1);
            } else if (t == 80) {
                shot(mc, "bt_editor_team");
                screen.setTab(2);
            } else if (t == 120) {
                shot(mc, "bt_editor_skins");
                screen.spec.skin = "builtin:ace_trainer_f";
                screen.setTab(2);
            } else if (t == 150) {
                shot(mc, "bt_editor_skins_slim");
                // Dresseur du monde : onglet Recompenses en plus
                TrainerSpec w = screen.spec;
                w.world = new TrainerSpec.WorldOptions();
                w.world.bp = 25;
                w.world.rematchHours = 24;
                w.world.lossCooldownMinutes = 15;
                w.world.items.add("cobblemon:rare_candy 3");
                w.world.commands.add("cobbledollars give %player% 500");
                w.world.winMessage = "Reviens quand tu seras pret !";
                screen = new TrainerEditorScreen("world", "pecheur_lac", w, meta());
                mc.method_1507(screen);
            } else if (t == 175) {
                screen.setTab(3);
            } else if (t == 200) {
                shot(mc, "bt_editor_world_rewards");
            } else if (t == 220) {
                String server = System.getProperty("cobblepulse_battles.clientserver", "");
                if (server.isBlank()) {
                    Battletower.LOG.info("[Battletower][clienttest] CLIENT TEST DONE");
                    mc.method_1592();
                    return;
                }
                Battletower.LOG.info("[Battletower][clienttest] connexion a {}", server);
                connectedAt = ticks;
                net.minecraft.class_412.method_36877(new class_442(), mc,
                        net.minecraft.class_639.method_2950(server),
                        new net.minecraft.class_642("CI", server, net.minecraft.class_642.class_8678.field_45611), false, null);
            } else if (connectedAt > 0 && ticks - connectedAt > 6000) {
                Battletower.LOG.error("[Battletower][clienttest] test avec le serveur trop long, arret");
                mc.method_1592();
            }
        } catch (Throwable e) {
            Battletower.LOG.error("[Battletower][clienttest] erreur", e);
            mc.method_1592();
        }
    }
}
