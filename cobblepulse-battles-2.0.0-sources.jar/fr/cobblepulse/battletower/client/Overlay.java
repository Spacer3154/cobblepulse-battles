package fr.cobblepulse.battletower.client;

import net.minecraft.class_437;

/** Fenetre affichee par-dessus un menu (saisie, selecteurs) : le menu reste derriere et y revient a l'annulation. */
interface Overlay {
    class_437 parentScreen();

    void setParentScreen(class_437 s);
}
