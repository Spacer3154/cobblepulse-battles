package fr.cobblepulse.battletower.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import io.netty.buffer.Unpooled;
import org.lwjgl.glfw.GLFW;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.class_1109;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_5348;
import net.minecraft.class_9129;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * Ecran generique des menus CobblePulse (boutique, GTS, STS, warps, homes, kits, editeurs...). Le contenu vient du
 * serveur ; chaque entree est une carte (icone, nom, deux lignes de description, detail complet au survol), les actions
 * de navigation forment la barre du bas. Les listes defilent et proposent une recherche. Clic gauche, clic droit,
 * Maj + clic et clic molette sont transmis tels quels au serveur.
 */
public final class MenuScreen extends class_437 {
    record Entry(int slot, class_1799 stack, boolean click, List<class_2561> lore, String key) {}

    private static final int CARD_W = 172;
    private static final int CARD_H = 40;
    private static final int GAP = 6;
    private static final int HEADER = 28;
    private static final int BAR_H = 20;

    private int id;
    private boolean list;
    private int rows;
    private class_2561 menuTitle = class_2561.method_43470("CobblePulse");
    private String titleKey = "";
    private final List<Entry> content = new ArrayList<>();
    private final List<Entry> bar = new ArrayList<>();
    private class_342 search;
    private String query = "";
    private double scroll;
    private int maxScroll;
    private class_2561 notice;
    private long noticeUntil;

    // geometrie calculee a chaque image
    private int px, py, pw, ph, ax, ay, aw, ah, cols, cardW;
    private final List<int[]> boxes = new ArrayList<>(); // {0 = carte / 1 = barre, index, x, y, w, h}
    private Entry hovered;

    MenuScreen(JsonObject o) {
        super(class_2561.method_43470("CobblePulse"));
        load(o);
    }

    // ------------------------------------------------------------------ donnees

    void update(JsonObject o) {
        boolean hadSearch = searchable();
        load(o);
        if (field_22787 != null && hadSearch != searchable()) method_41843();
    }

    private void load(JsonObject o) {
        class_2561 t = parse(Ui.str(o, "title", "CobblePulse"));
        boolean same = t.getString().equals(titleKey);
        id = Ui.num(o, "id", 0);
        list = Ui.bool(o, "list", false);
        rows = Ui.num(o, "rows", 6);
        menuTitle = brighten(t);
        titleKey = t.getString();
        content.clear();
        bar.clear();
        for (JsonElement el : Ui.arr(o, "items")) {
            JsonObject it = el.getAsJsonObject();
            class_1799 st = decode(Ui.str(it, "i", ""));
            List<class_2561> lore = new ArrayList<>();
            class_9290 il = st.method_57824(class_9334.field_49632);
            if (il != null) lore.addAll(il.comp_2400());
            StringBuilder k = new StringBuilder(st.method_7964().getString());
            for (class_2561 l : lore) k.append(' ').append(l.getString());
            Entry e = new Entry(Ui.num(it, "s", 0), st, Ui.bool(it, "c", false), lore, norm(k.toString()));
            if (Ui.bool(it, "bar", false)) bar.add(e);
            else content.add(e);
        }
        if (!same) {
            scroll = 0;
            query = "";
            if (search != null) search.method_1852("");
        }
    }

    private static class_2561 parse(String json) {
        try {
            var conn = class_310.method_1551().method_1562();
            class_5250 c = conn == null ? null : class_2561.class_2562.method_10877(json, conn.method_29091());
            return c == null ? class_2561.method_43470(json) : c;
        } catch (Exception e) {
            return class_2561.method_43470(json);
        }
    }

    static class_1799 decode(String b64) {
        var conn = class_310.method_1551().method_1562();
        if (conn == null || b64.isEmpty()) return new class_1799(class_1802.field_8077);
        class_9129 buf = new class_9129(Unpooled.wrappedBuffer(Base64.getDecoder().decode(b64)), conn.method_29091());
        try {
            return class_1799.field_49268.decode(buf);
        } catch (Exception e) {
            return new class_1799(class_1802.field_8077);
        } finally {
            buf.release();
        }
    }

    static String norm(String s) {
        String n = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.toLowerCase(Locale.ROOT);
    }

    /** Les titres sont ecrits pour le fond clair d'un coffre : les couleurs sombres sont eclaircies. */
    static class_2561 brighten(class_2561 c) {
        class_5250 out = class_2561.method_43473();
        c.method_27658((style, text) -> {
            class_5251 col = style.method_10973();
            class_2583 s = style;
            if (col == null) s = style.method_36139(Ui.TEXT & 0xFFFFFF);
            else {
                int v = col.method_27716();
                int r = (v >> 16) & 255, g = (v >> 8) & 255, b = v & 255;
                double lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0;
                // gris fonce / noir (texte principal d'un titre de coffre) -> texte clair ; couleurs sombres -> eclaircies
                if (v == 0x555555 || v == 0) s = style.method_36139(Ui.TEXT & 0xFFFFFF);
                else if (lum < 0.35) s = style.method_36139(((r + 255) / 2 << 16) | ((g + 255) / 2 << 8) | ((b + 255) / 2));
            }
            out.method_10852(class_2561.method_43470(text).method_27696(s));
            return Optional.empty();
        }, class_2583.field_24360);
        return out;
    }

    void notice(class_2561 c) {
        notice = c;
        noticeUntil = System.currentTimeMillis() + 5000;
    }

    private boolean searchable() {
        return list && content.size() > 12;
    }

    private List<Entry> visible() {
        if (query.isBlank()) return content;
        String q = norm(query.trim());
        List<Entry> out = new ArrayList<>();
        for (Entry e : content) if (e.key.contains(q)) out.add(e);
        return out;
    }

    @Override
    public class_2561 method_25440() {
        return menuTitle;
    }

    // ------------------------------------------------------------------ mise en page

    @Override
    protected void method_25426() {
        layout();
        search = null;
        if (searchable()) {
            search = new class_342(field_22793, px + pw - 12 - 150, py + 6, 150, 16, class_2561.method_43470("Recherche"));
            search.method_47404(class_2561.method_43470("Rechercher…").method_54663(Ui.MUTED & 0xFFFFFF));
            search.method_1852(query);
            search.method_1863(v -> {
                query = v;
                scroll = 0;
            });
            method_37063(search);
        }
    }

    /** Groupes de cartes : une grille pour les listes, une ligne par rangee du menu sinon. */
    private List<List<Entry>> groups(List<Entry> vis) {
        List<List<Entry>> out = new ArrayList<>();
        if (list) {
            out.add(vis);
            return out;
        }
        int last = -1;
        for (Entry e : vis) {
            int r = e.slot < rows * 9 ? e.slot / 9 : 99;
            if (r != last || out.isEmpty()) {
                out.add(new ArrayList<>());
                last = r;
            }
            out.get(out.size() - 1).add(e);
        }
        return out;
    }

    /** Largeur des cartes d'une rangee : une rangee d'un menu (boutons -64/+64...) tient sur une ligne si possible. */
    private int groupW(int n) {
        if (list || n <= cols) return cardW;
        int w = (aw - 6 - (n - 1) * GAP) / n;
        return w >= 78 ? w : cardW;
    }

    private int perLine(int n) {
        return groupW(n) == cardW ? cols : n;
    }

    private int contentHeight(List<List<Entry>> groups) {
        int h = 0;
        for (List<Entry> g : groups) {
            if (g.isEmpty()) continue;
            int lines = (g.size() + perLine(g.size()) - 1) / perLine(g.size());
            h += lines * (CARD_H + GAP) + (list ? 0 : 4);
        }
        return Math.max(0, h - GAP - (list ? 0 : 4));
    }

    private List<List<Integer>> barLines = new ArrayList<>();
    private boolean barCompact;
    private int noticeH;

    private int barWidth(Entry e) {
        return barCompact ? 20 : 24 + Math.min(130, field_22793.method_27525(e.stack.method_7964())) + 6;
    }

    /** Barre d'actions : une ou deux lignes de boutons avec libelle, sinon icones seules. */
    private List<List<Integer>> barLayout() {
        for (int attempt = 0; attempt < 2; attempt++) {
            barCompact = attempt == 1;
            List<List<Integer>> lines = new ArrayList<>();
            List<Integer> cur = new ArrayList<>();
            int w = 0;
            for (int i = 0; i < bar.size(); i++) {
                int bw = barWidth(bar.get(i)) + 6;
                if (!cur.isEmpty() && w + bw - 6 > aw) {
                    lines.add(cur);
                    cur = new ArrayList<>();
                    w = 0;
                }
                cur.add(i);
                w += bw;
            }
            if (!cur.isEmpty()) lines.add(cur);
            if (lines.size() <= 2 || barCompact) return lines;
        }
        return new ArrayList<>();
    }

    private void layout() {
        pw = Math.min(field_22789 - 24, 640);
        px = (field_22789 - pw) / 2;
        int inner = pw - 20 - 6;
        cols = Math.max(1, (inner + GAP) / (CARD_W + GAP));
        cardW = (inner - (cols - 1) * GAP) / cols;
        aw = pw - 20;
        int contentH = contentHeight(groups(visible()));
        barLines = barLayout();
        int lines = barLines.isEmpty() ? 0 : barLines.size();
        int barH = bar.isEmpty() ? 0 : lines * BAR_H + (lines - 1) * 4 + 10;
        noticeH = hasNotice() ? Math.min(2, field_22793.method_1728(notice, aw - 16).size()) * 10 + 10 : 0;
        barH += noticeH;
        if (list) ph = field_22790 - 16;
        else ph = Math.min(field_22790 - 16, HEADER + 8 + Math.max(contentH, 24) + 10 + barH);
        py = (field_22790 - ph) / 2;
        ax = px + 10;
        ay = py + HEADER + 8;
        aw = pw - 20;
        ah = ph - HEADER - 8 - 10 - barH;
        maxScroll = Math.max(0, contentH - ah);
        scroll = class_3532.method_15350(scroll, 0, maxScroll);
    }

    // ------------------------------------------------------------------ rendu

    @Override
    public void method_25394(class_332 g, int mx, int my, float pt) {
        method_52752(g);
        layout();
        boxes.clear();
        hovered = null;
        Ui.panel(g, px, py, pw, ph, Ui.PANEL, Ui.BORDER);
        g.method_25294(px + 1, py + 1, px + pw - 1, py + HEADER, Ui.PANEL2);
        g.method_25294(px + 1, py + HEADER, px + pw - 1, py + HEADER + 1, Ui.BORDER);
        int titleMax = pw - 24 - (search != null ? 160 : field_22793.method_1727("Échap pour fermer") + 10);
        drawClipped(g, menuTitle, px + 12, py + 10, titleMax, Ui.TEXT);
        if (search == null) {
            String hint = "Échap pour fermer";
            g.method_51433(field_22793, hint, px + pw - 12 - field_22793.method_1727(hint), py + 10, Ui.MUTED, false);
        }

        // cartes
        List<Entry> vis = visible();
        List<List<Entry>> groups = groups(vis);
        g.method_44379(ax, ay, ax + aw, ay + ah);
        int y = ay - (int) scroll;
        for (List<Entry> grp : groups) {
            if (grp.isEmpty()) continue;
            int n = grp.size();
            int w = groupW(n);
            int per = perLine(n);
            int lineW = Math.min(n, per) * w + (Math.min(n, per) - 1) * GAP;
            int x0 = list ? ax : ax + (aw - 6 - lineW) / 2;
            for (int i = 0; i < n; i++) {
                int cx = x0 + (i % per) * (w + GAP);
                int cy = y + (i / per) * (CARD_H + GAP);
                Entry e = grp.get(i);
                if (cy + CARD_H >= ay && cy <= ay + ah) {
                    boolean hov = Ui.in(mx, my, cx, cy, w, CARD_H) && Ui.in(mx, my, ax, ay, aw, ah);
                    if (hov) hovered = e;
                    drawCard(g, e, cx, cy, w, CARD_H, hov);
                    boxes.add(new int[]{0, content.indexOf(e), cx, cy, w, CARD_H});
                }
            }
            y += ((n + per - 1) / per) * (CARD_H + GAP) + (list ? 0 : 4);
        }
        g.method_44380();
        if (vis.isEmpty()) {
            String empty = query.isBlank() ? "Rien à afficher pour le moment." : "Aucun résultat pour « " + query.trim() + " ».";
            g.method_51433(field_22793, empty, ax + (aw - field_22793.method_1727(empty)) / 2, ay + 16, Ui.MUTED, false);
        }
        if (maxScroll > 0) {
            int track = ah;
            int knob = Math.max(16, track * ah / (ah + maxScroll));
            int ky = ay + (int) ((track - knob) * (scroll / maxScroll));
            g.method_25294(ax + aw - 3, ay, ax + aw, ay + track, 0x40FFFFFF);
            g.method_25294(ax + aw - 3, ky, ax + aw, ky + knob, Ui.ACCENT);
        }

        // barre d'actions
        if (!bar.isEmpty()) {
            int by = py + ph - 8 - barLines.size() * (BAR_H + 4) + 4;
            for (List<Integer> line : barLines) {
                int total = -6;
                for (int i : line) total += barWidth(bar.get(i)) + 6;
                int bx = px + (pw - total) / 2;
                for (int i : line) {
                    Entry e = bar.get(i);
                    int w = barWidth(e);
                    boolean hov = Ui.in(mx, my, bx, by, w, BAR_H);
                    if (hov) hovered = e;
                    Ui.panel(g, bx, by, w, BAR_H, hov && e.click ? Ui.CARD_ON : Ui.CARD, hov ? (e.click ? Ui.ACCENT : Ui.MUTED) : Ui.BORDER);
                    g.method_51427(e.stack, bx + 2, by + 2);
                    if (!barCompact) drawClipped(g, e.stack.method_7964(), bx + 22, by + 6, w - 26, Ui.TEXT);
                    boxes.add(new int[]{1, i, bx, by, w, BAR_H});
                    bx += w + 6;
                }
                by += BAR_H + 4;
            }
        }

        super.method_25394(g, mx, my, pt);

        // message du serveur (achat reussi, erreur...) : les menus couvrent le chat
        if (noticeH > 0) {
            g.method_51448().method_22903();
            g.method_51448().method_46416(0, 0, 300);
            List<net.minecraft.class_5481> lines = field_22793.method_1728(notice, aw - 16);
            int nh = noticeH - 6;
            int ny = ay + ah + 6;
            Ui.panel(g, ax, ny, aw, nh, 0xF0122133, Ui.ACCENT);
            for (int i = 0; i < Math.min(2, lines.size()); i++) g.method_51430(field_22793, lines.get(i), ax + 8, ny + 5 + i * 10, Ui.TEXT, false);
            g.method_51448().method_22909();
        }

        if (hovered != null) {
            List<class_2561> tip = new ArrayList<>();
            tip.add(hovered.stack.method_7964());
            tip.addAll(hovered.lore);
            g.method_51434(field_22793, tip, mx, my);
        }
    }

    private void drawCard(class_332 g, Entry e, int x, int y, int w, int h, boolean hov) {
        Ui.panel(g, x, y, w, h, hov && e.click ? Ui.CARD_ON : Ui.CARD, hov ? (e.click ? Ui.ACCENT : Ui.MUTED) : Ui.BORDER);
        if (w < 130) {
            // carte etroite (rangee de boutons) : icone au-dessus du nom, description au survol
            g.method_51427(e.stack, x + (w - 16) / 2, y + 4);
            g.method_51431(field_22793, e.stack, x + (w - 16) / 2, y + 4);
            class_2561 name = e.stack.method_7964();
            List<net.minecraft.class_5481> nl = field_22793.method_1728(name, w - 6);
            if (nl.size() <= 1) {
                int nw = Math.min(field_22793.method_27525(name), w - 6);
                drawClipped(g, name, x + (w - nw) / 2, y + 25, w - 6, Ui.TEXT);
            } else {
                g.method_51430(field_22793, nl.get(0), x + (w - field_22793.method_30880(nl.get(0))) / 2, y + 21, Ui.TEXT, false);
                net.minecraft.class_5481 second = nl.get(1);
                if (nl.size() > 2) {
                    // reste du nom coupe proprement
                    StringBuilder rest = new StringBuilder();
                    for (int k = 1; k < nl.size(); k++) nl.get(k).accept((idx, st, cp) -> {
                        rest.appendCodePoint(cp);
                        return true;
                    });
                    class_2561 rc = class_2561.method_43470(rest.toString()).method_27696(name.method_10866());
                    int rw = Math.min(field_22793.method_27525(rc), w - 6);
                    drawClipped(g, rc, x + (w - rw) / 2, y + 30, w - 6, Ui.TEXT);
                } else g.method_51430(field_22793, second, x + (w - field_22793.method_30880(second)) / 2, y + 30, Ui.TEXT, false);
            }
            return;
        }
        g.method_51448().method_22903();
        g.method_51448().method_46416(x + 5, y + (h - 24) / 2f, 0);
        g.method_51448().method_22905(1.5f, 1.5f, 1f);
        g.method_51427(e.stack, 0, 0);
        g.method_51431(field_22793, e.stack, 0, 0);
        g.method_51448().method_22909();
        List<class_2561> lines = new ArrayList<>();
        for (class_2561 l : e.lore) {
            if (lines.size() >= 2) break;
            if (!l.getString().isBlank()) lines.add(l);
        }
        int tx = x + 35;
        int tw = w - 40;
        int ty = y + (h - ((1 + lines.size()) * 10 - 1)) / 2;
        drawClipped(g, e.stack.method_7964(), tx, ty, tw, Ui.TEXT);
        for (int i = 0; i < lines.size(); i++) drawClipped(g, lines.get(i), tx, ty + 10 * (i + 1), tw, Ui.MUTED);
    }

    private void drawClipped(class_332 g, class_2561 c, int x, int y, int maxW, int color) {
        if (field_22793.method_27525(c) <= maxW) {
            g.method_51439(field_22793, c, x, y, color, false);
            return;
        }
        class_5348 cut = field_22793.method_1714(c, Math.max(0, maxW - field_22793.method_1727("…")));
        g.method_51430(field_22793, class_2477.method_10517().method_30934(class_5348.method_29433(cut, class_5348.method_29430("…"))), x, y, color, false);
    }

    @Override
    public void method_25420(class_332 g, int mx, int my, float pt) {
    }

    // ------------------------------------------------------------------ interactions

    @Override
    public boolean method_25402(double mx, double my, int button) {
        if (super.method_25402(mx, my, button)) return true;
        for (int[] b : boxes) {
            if (!Ui.in(mx, my, b[2], b[3], b[4], b[5])) continue;
            if (b[0] == 0 && !Ui.in(mx, my, ax, ay, aw, ah)) continue;
            Entry e = b[0] == 0 ? content.get(b[1]) : bar.get(b[1]);
            if (!e.click) return true;
            String kind = button == 1 ? "right" : button == 2 ? "middle" : method_25442() ? "shift" : "left";
            click(e.slot, kind);
            return true;
        }
        return false;
    }

    void click(int slot, String kind) {
        JsonObject o = new JsonObject();
        o.addProperty("id", id);
        o.addProperty("slot", slot);
        o.addProperty("kind", kind);
        Ui.send("menu_click", o);
        if (field_22787 != null) field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
    }

    @Override
    public boolean method_25401(double mx, double my, double sx, double sy) {
        if (maxScroll > 0) {
            scroll = class_3532.method_15350(scroll - sy * 26, 0, maxScroll);
            return true;
        }
        return super.method_25401(mx, my, sx, sy);
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        boolean typing = search != null && search.method_25370();
        if (!typing && field_22787 != null && field_22787.field_1690.field_1822.method_1417(key, scan)) {
            method_25419();
            return true;
        }
        if (key == GLFW.GLFW_KEY_F && (mods & GLFW.GLFW_MOD_CONTROL) != 0 && search != null) {
            method_25395(search);
            return true;
        }
        return super.method_25404(key, scan, mods);
    }

    @Override
    public void method_25419() {
        JsonObject o = new JsonObject();
        o.addProperty("id", id);
        Ui.send("menu_close", o);
        super.method_25419();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // ------------------------------------------------------------------ auto-test (client de CI)

    int menuId() {
        return id;
    }

    List<String> entryNames() {
        List<String> out = new ArrayList<>();
        for (Entry e : content) out.add(e.stack.method_7964().getString());
        return out;
    }

    List<String> barNames() {
        List<String> out = new ArrayList<>();
        for (Entry e : bar) out.add(e.stack.method_7964().getString());
        return out;
    }

    boolean hasNotice() {
        return notice != null && System.currentTimeMillis() < noticeUntil;
    }

    String noticeText() {
        return notice == null ? "-" : notice.getString();
    }

    int visibleCount() {
        return visible().size();
    }

    boolean hasSearch() {
        return search != null;
    }

    void setQuery(String q) {
        query = q;
        if (search != null) search.method_1852(q);
    }

    /** Clique la premiere entree (cartes puis barre) dont le nom contient le texte. */
    boolean clickNamed(String part, String kind) {
        String p = norm(part);
        for (Entry e : content) if (e.click && norm(e.stack.method_7964().getString()).contains(p)) {
            click(e.slot, kind);
            return true;
        }
        for (Entry e : bar) if (e.click && norm(e.stack.method_7964().getString()).contains(p)) {
            click(e.slot, kind);
            return true;
        }
        return false;
    }

    boolean clickFirst(String kind) {
        for (Entry e : content) if (e.click) {
            click(e.slot, kind);
            return true;
        }
        return false;
    }
}
