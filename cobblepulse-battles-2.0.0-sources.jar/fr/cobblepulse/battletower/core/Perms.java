package fr.cobblepulse.battletower.core;

import fr.cobblepulse.battletower.integration.LuckPermsBridge;
import java.util.function.Predicate;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

/**
 * Permissions LuckPerms du cahier des charges. Sans LuckPerms (ou noeud non defini) :
 * noeuds joueurs autorises, VIP refuses, staff = operateurs niveau 2, admin = operateurs niveau 3.
 */
public final class Perms {
    public static final String USE = "cobblepulse.battletower.use";
    public static final String SHOP = "cobblepulse.battletower.shop";
    public static final String VIP_BOOST = "cobblepulse.battletower.vip.bp_boost";
    public static final String STAFF_DISQUALIFY = "cobblepulse.battletower.staff.disqualify";
    public static final String STAFF_RESET_COOLDOWN = "cobblepulse.battletower.staff.resetcooldown";
    public static final String ADMIN = "cobblepulse.battletower.admin";
    public static final String ADMIN_TOGGLE = "cobblepulse.battletower.admin.toggle";
    public static final String ADMIN_NPC = "cobblepulse.battletower.admin.npc";
    public static final String ADMIN_SHOP = "cobblepulse.battletower.admin.shop";
    public static final String ADMIN_BOSS = "cobblepulse.battletower.admin.boss";
    public static final String ADMIN_RELOAD = "cobblepulse.battletower.admin.reload";
    public static final String ADMIN_BP = "cobblepulse.battletower.admin.bp";

    private Perms() {}

    public static boolean player(class_3222 p, String node) {
        Boolean v = LuckPermsBridge.check(p, node);
        return v == null || v;
    }

    public static boolean vip(class_3222 p, String node) {
        Boolean v = LuckPermsBridge.check(p, node);
        return v != null && v;
    }

    public static boolean staff(class_3222 p, String node) {
        Boolean v = LuckPermsBridge.check(p, node);
        if (v != null) return v;
        Boolean admin = LuckPermsBridge.check(p, ADMIN + ".*");
        return admin != null ? admin : p.method_5687(2);
    }

    /** Noeud admin : le noeud precis, sinon le joker admin.*, sinon operateur niveau 3. */
    public static boolean admin(class_3222 p, String node) {
        Boolean v = LuckPermsBridge.check(p, node);
        if (v != null) return v;
        Boolean all = LuckPermsBridge.check(p, ADMIN + ".*");
        return all != null ? all : p.method_5687(3);
    }

    public static boolean isAdmin(class_3222 p) {
        return admin(p, ADMIN_NPC) || admin(p, ADMIN_TOGGLE);
    }

    public static Predicate<class_2168> playerReq(String node) {
        return src -> !src.method_43737() || player(src.method_44023(), node);
    }

    public static Predicate<class_2168> staffReq(String node) {
        return src -> !src.method_43737() || staff(src.method_44023(), node);
    }

    public static Predicate<class_2168> adminReq(String node) {
        return src -> !src.method_43737() || admin(src.method_44023(), node);
    }
}
