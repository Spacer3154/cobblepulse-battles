package fr.cobblepulse.battletower.command;

import com.cobblemon.mod.common.entity.npc.NPCEntity;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.tree.LiteralCommandNode;
import fr.cobblepulse.battletower.Battletower;
import fr.cobblepulse.battletower.config.Cfg;
import fr.cobblepulse.battletower.core.Loc;
import fr.cobblepulse.battletower.core.Msg;
import fr.cobblepulse.battletower.core.Perms;
import fr.cobblepulse.battletower.core.TimeFmt;
import fr.cobblepulse.battletower.data.FloorEntry;
import fr.cobblepulse.battletower.data.PlayerData;
import fr.cobblepulse.battletower.data.RunState;
import fr.cobblepulse.battletower.data.TowerData;
import fr.cobblepulse.battletower.data.TrainerSpec;
import fr.cobblepulse.battletower.economy.BattlePoints;
import fr.cobblepulse.battletower.menu.AdminMenus;
import fr.cobblepulse.battletower.menu.Menus;
import fr.cobblepulse.battletower.net.EditorService;
import fr.cobblepulse.battletower.npc.TrainerNpcs;
import fr.cobblepulse.battletower.storage.PlayerStore;
import fr.cobblepulse.battletower.tower.DailyBoss;
import fr.cobblepulse.battletower.tower.TowerConfig;
import fr.cobblepulse.battletower.tower.TowerManager;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/** /battletower (alias /bt) : joueurs, staff et administration. */
public final class Commands {
    private static final SuggestionProvider<class_2168> BOSSES =
            (ctx, b) -> class_2172.method_9265(TowerConfig.bosses().bosses.keySet(), b);
    private static final SuggestionProvider<class_2168> TOWERS = (ctx, b) -> class_2172.method_9265(
            TowerConfig.towers().stream().map(t -> t.id).toList(), b);
    private static final SuggestionProvider<class_2168> EXTRA_TOWERS = (ctx, b) -> class_2172.method_9265(
            TowerConfig.extraTowers().stream().map(t -> t.id).toList(), b);
    private static final SuggestionProvider<class_2168> KNOWN_PLAYERS =
            (ctx, b) -> class_2172.method_9265(PlayerStore.names(), b);

    private Commands() {}

    private interface PlayerAction {
        void run(class_3222 p) throws CommandSyntaxException;
    }

    private static int player(CommandContext<class_2168> ctx, PlayerAction a) throws CommandSyntaxException {
        a.run(ctx.getSource().method_9207());
        return 1;
    }

    private static int floorArg(CommandContext<class_2168> ctx) {
        return IntegerArgumentType.getInteger(ctx, "etage");
    }

    private static String towerArg(CommandContext<class_2168> ctx) {
        return StringArgumentType.getString(ctx, "tour");
    }

    /** {@code <etage>} puis {@code [tour]} facultatif (tour principale par defaut). */
    private static com.mojang.brigadier.builder.RequiredArgumentBuilder<class_2168, Integer> floorThenTower(
            java.util.function.BiConsumer<class_3222, FloorEntry> action) {
        return method_9244("etage", IntegerArgumentType.integer(1, 200))
                .executes(ctx -> player(ctx, p -> withFloor(p, TowerConfig.MAIN, floorArg(ctx), action)))
                .then(method_9244("tour", StringArgumentType.word()).suggests(TOWERS)
                        .executes(ctx -> player(ctx, p -> withFloor(p, towerArg(ctx), floorArg(ctx), action))));
    }

    private static void withFloor(class_3222 p, String tower, int floor, java.util.function.BiConsumer<class_3222, FloorEntry> action) {
        fr.cobblepulse.battletower.data.TowerData t = TowerConfig.tower(tower);
        if (t == null) {
            Msg.send(p, "tower.unknown_tower", "tower", tower);
            return;
        }
        FloorEntry fe = TowerConfig.floor(t, floor);
        if (fe == null || floor > TowerConfig.size(t)) {
            Msg.send(p, "admin.floor_unknown", "floor", floor);
            return;
        }
        action.accept(p, fe);
    }

    public static void register(CommandDispatcher<class_2168> d) {
        LiteralCommandNode<class_2168> root = d.register(method_9247("battletower").requires(Perms.playerReq(Perms.USE))
                .executes(ctx -> player(ctx, Menus::main))
                .then(method_9247("top").executes(ctx -> player(ctx, Menus::leaderboard)))
                .then(method_9247("succes").executes(ctx -> player(ctx, Menus::achievements)))
                .then(method_9247("achievements").executes(ctx -> player(ctx, Menus::achievements)))
                .then(method_9247("start").executes(ctx -> player(ctx, TowerManager::startAssault))
                        .then(method_9244("tour", StringArgumentType.word()).suggests(TOWERS)
                                .executes(ctx -> player(ctx, p -> TowerManager.startAssault(p, towerArg(ctx))))))
                .then(method_9247("tours").executes(ctx -> player(ctx, Menus::chooseTower)))
                .then(method_9247("engage").executes(ctx -> player(ctx, TowerManager::engage)))
                .then(method_9247("pc").executes(ctx -> player(ctx, TowerManager::openPc)))
                .then(method_9247("abandon").executes(ctx -> player(ctx, p -> {
                    RunState r = TowerManager.run(p.method_5667());
                    if (r != null && r.daily) TowerManager.abandon(p);
                    else Menus.confirmAbandon(p);
                })))
                .then(method_9247("boss").executes(ctx -> player(ctx, DailyBoss::start))
                        .then(method_9247("create").requires(Perms.adminReq(Perms.ADMIN_BOSS)).then(method_9244("id", StringArgumentType.word())
                                .executes(ctx -> bossCreate(ctx.getSource(), StringArgumentType.getString(ctx, "id")))))
                        .then(method_9247("edit").requires(Perms.adminReq(Perms.ADMIN_BOSS)).then(method_9244("id", StringArgumentType.word()).suggests(BOSSES)
                                .executes(ctx -> player(ctx, p -> EditorService.openBoss(p, StringArgumentType.getString(ctx, "id"))))))
                        .then(method_9247("delete").requires(Perms.adminReq(Perms.ADMIN_BOSS)).then(method_9244("id", StringArgumentType.word()).suggests(BOSSES)
                                .executes(ctx -> bossDelete(ctx.getSource(), StringArgumentType.getString(ctx, "id")))))
                        .then(method_9247("list").requires(Perms.adminReq(Perms.ADMIN_BOSS)).executes(ctx -> {
                            Msg.send(ctx.getSource(), "admin.boss_list", "list", String.join(", ", TowerConfig.bosses().bosses.keySet()),
                                    "current", DailyBoss.currentId());
                            return 1;
                        }))
                        .then(method_9247("settp").requires(Perms.adminReq(Perms.ADMIN_BOSS)).executes(ctx -> player(ctx, p -> {
                            TowerConfig.data().bossArrival = Loc.of(p);
                            TowerConfig.saveFloors();
                            Msg.send(p, "admin.boss_settp_done", "loc", TowerConfig.data().bossArrival.pretty());
                        })))
                        .then(method_9247("spawn").requires(Perms.adminReq(Perms.ADMIN_BOSS)).executes(ctx -> player(ctx, Commands::spawnBossNpc)))
                        .then(method_9247("rotate").requires(Perms.adminReq(Perms.ADMIN_BOSS)).executes(ctx -> {
                            DailyBoss.rotateIfNeeded(true);
                            Msg.send(ctx.getSource(), "admin.boss_rotated", "boss", DailyBoss.currentId());
                            return 1;
                        })))
                .then(method_9247("npc").requires(Perms.adminReq(Perms.ADMIN_NPC))
                        .then(method_9247("spawn").then(floorThenTower(Commands::npcSpawn)))
                        .then(method_9247("settp").then(floorThenTower(Commands::npcSetTp)))
                        .then(method_9247("edit").executes(ctx -> player(ctx, Commands::npcEditTargeted))
                                .then(floorThenTower((p, fe) -> EditorService.openFloor(p, fe.tower, fe.floor))))
                        .then(method_9247("remove").then(floorThenTower(Commands::npcRemove)))
                        .then(method_9247("tp").then(floorThenTower((p, fe) -> {
                            if (fe.arrival != null) fe.arrival.teleport(p);
                            else Msg.send(p, "admin.floor_no_tp_admin");
                        }))))
                .then(method_9247("tour").requires(Perms.adminReq(Perms.ADMIN_NPC))
                        .executes(ctx -> player(ctx, AdminMenus::towers))
                        .then(method_9247("liste").executes(ctx -> {
                            for (fr.cobblepulse.battletower.data.TowerData t : TowerConfig.towers()) {
                                Msg.send(ctx.getSource(), "admin.tower_line", "id", t.id, "tower", TowerConfig.name(t), "floors", TowerConfig.size(t),
                                        "ready", AdminMenus.countConfigured(t));
                            }
                            return 1;
                        }))
                        .then(method_9247("creer").then(method_9244("id", StringArgumentType.word()).then(method_9244("etages", IntegerArgumentType.integer(1, 200))
                                .executes(ctx -> towerCreate(ctx.getSource(), StringArgumentType.getString(ctx, "id"), IntegerArgumentType.getInteger(ctx, "etages"), ""))
                                .then(method_9244("nom", StringArgumentType.greedyString()).executes(ctx -> towerCreate(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "id"), IntegerArgumentType.getInteger(ctx, "etages"), StringArgumentType.getString(ctx, "nom")))))))
                        .then(method_9247("etages").then(method_9244("tour", StringArgumentType.word()).suggests(EXTRA_TOWERS)
                                .then(method_9244("etages", IntegerArgumentType.integer(1, 200)).executes(ctx -> towerEdit(ctx.getSource(), towerArg(ctx), t -> {
                                    TowerConfig.resize(t, IntegerArgumentType.getInteger(ctx, "etages"));
                                })))))
                        .then(method_9247("nom").then(method_9244("tour", StringArgumentType.word()).suggests(EXTRA_TOWERS)
                                .then(method_9244("nom", StringArgumentType.greedyString()).executes(ctx -> towerEdit(ctx.getSource(), towerArg(ctx), t -> {
                                    t.name = StringArgumentType.getString(ctx, "nom");
                                    TowerConfig.save(t);
                                })))))
                        .then(method_9247("cooldown").then(method_9244("tour", StringArgumentType.word()).suggests(EXTRA_TOWERS)
                                .then(method_9244("heures", IntegerArgumentType.integer(-1, 8760)).executes(ctx -> towerEdit(ctx.getSource(), towerArg(ctx), t -> {
                                    t.cooldownHours = IntegerArgumentType.getInteger(ctx, "heures");
                                    TowerConfig.save(t);
                                })))))
                        .then(method_9247("recompense").then(method_9244("tour", StringArgumentType.word()).suggests(EXTRA_TOWERS)
                                .then(method_9244("bp", IntegerArgumentType.integer(0)).executes(ctx -> towerEdit(ctx.getSource(), towerArg(ctx), t -> {
                                    t.finalBp = IntegerArgumentType.getInteger(ctx, "bp");
                                    TowerConfig.save(t);
                                })))))
                        .then(method_9247("sortie").then(method_9244("tour", StringArgumentType.word()).suggests(TOWERS).executes(ctx -> player(ctx, p -> {
                            fr.cobblepulse.battletower.data.TowerData t = TowerConfig.tower(towerArg(ctx));
                            if (t == null) {
                                Msg.send(p, "tower.unknown_tower", "tower", towerArg(ctx));
                                return;
                            }
                            t.exit = Loc.of(p);
                            TowerConfig.save(t);
                            Msg.send(p, "admin.exit_set", "loc", t.exit.pretty());
                        }))))
                        .then(method_9247("supprimer").then(method_9244("tour", StringArgumentType.word()).suggests(EXTRA_TOWERS).executes(ctx -> {
                            return towerDelete(ctx.getSource(), towerArg(ctx)) ? 1 : 0;
                        }))))
                .then(method_9247("shop").requires(Perms.adminReq(Perms.ADMIN_SHOP))
                        .then(method_9247("spawn").executes(ctx -> player(ctx, Commands::shopSpawn)))
                        .then(method_9247("remove").executes(ctx -> player(ctx, Commands::shopRemove))))
                .then(method_9247("staff").requires(src -> !src.method_43737() || Perms.staff(src.method_44023(), Perms.STAFF_DISQUALIFY)
                                || Perms.staff(src.method_44023(), Perms.STAFF_RESET_COOLDOWN))
                        .then(method_9247("disqualify").requires(Perms.staffReq(Perms.STAFF_DISQUALIFY))
                                .then(method_9244("joueurs", class_2186.method_9308()).executes(ctx -> {
                                    Collection<class_3222> targets = class_2186.method_9312(ctx, "joueurs");
                                    String by = ctx.getSource().method_9214();
                                    int n = 0;
                                    for (class_3222 t : targets) {
                                        if (TowerManager.disqualify(t.method_5667(), by)) {
                                            n++;
                                            Msg.send(ctx.getSource(), "staff.disqualified", "player", t.method_7334().getName());
                                        } else {
                                            Msg.send(ctx.getSource(), "staff.not_running", "player", t.method_7334().getName());
                                        }
                                    }
                                    return n;
                                })))
                        .then(method_9247("resetcooldown").requires(Perms.staffReq(Perms.STAFF_RESET_COOLDOWN))
                                .then(method_9244("joueur", StringArgumentType.word()).suggests(KNOWN_PLAYERS).executes(ctx -> {
                                    String name = StringArgumentType.getString(ctx, "joueur");
                                    PlayerData pd = PlayerStore.byName(name);
                                    if (pd == null) {
                                        Msg.send(ctx.getSource(), "general.player_not_found", "player", name);
                                        return 0;
                                    }
                                    pd.cooldownUntil = 0;
                                    for (PlayerData.TowerRecord tr : pd.towers.values()) tr.cooldownUntil = 0;
                                    PlayerStore.save(pd);
                                    Battletower.LOG.info("[Battletower] Cooldown de {} reinitialise par {}", pd.name, ctx.getSource().method_9214());
                                    Msg.send(ctx.getSource(), "staff.cooldown_reset", "player", pd.name);
                                    return 1;
                                })))
                        .then(method_9247("inspect").requires(Perms.staffReq(Perms.STAFF_DISQUALIFY))
                                .then(method_9244("joueur", StringArgumentType.word()).suggests(KNOWN_PLAYERS).executes(ctx -> inspect(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "joueur"))))))
                .then(method_9247("admin").requires(src -> !src.method_43737() || Perms.isAdmin(src.method_44023()) || Perms.admin(src.method_44023(), Perms.ADMIN_BP))
                        .executes(ctx -> player(ctx, AdminMenus::panel))
                        .then(method_9247("toggle").requires(Perms.adminReq(Perms.ADMIN_TOGGLE)).executes(ctx -> {
                            TowerManager.setOpen(!TowerManager.isOpen());
                            Msg.send(ctx.getSource(), TowerManager.isOpen() ? "admin.toggled_open" : "admin.toggled_closed");
                            return 1;
                        }))
                        .then(method_9247("reload").requires(Perms.adminReq(Perms.ADMIN_RELOAD)).executes(ctx -> {
                            Battletower.reload();
                            Msg.send(ctx.getSource(), "admin.reloaded");
                            return 1;
                        }))
                        .then(method_9247("setexit").requires(Perms.adminReq(Perms.ADMIN_NPC)).executes(ctx -> player(ctx, p -> {
                            TowerConfig.data().exit = Loc.of(p);
                            TowerConfig.saveFloors();
                            Msg.send(p, "admin.exit_set", "loc", TowerConfig.data().exit.pretty());
                        })))
                        .then(method_9247("floors").requires(Perms.adminReq(Perms.ADMIN_NPC)).executes(ctx -> player(ctx, p -> AdminMenus.floors(p, 0))))
                        .then(method_9247("bp").requires(Perms.adminReq(Perms.ADMIN_BP))
                                .then(bpOp("give")).then(bpOp("take")).then(bpOp("set"))))
                .then(method_9247("selftest").requires(src -> "true".equals(System.getProperty("battletower.selftest")) && Perms.adminReq(Perms.ADMIN_RELOAD).test(src))
                        .executes(ctx -> SelfTest.basic(ctx.getSource()))
                        .then(method_9247("ascension").executes(ctx -> SelfTest.ascension(ctx.getSource())))
                        .then(method_9247("defeat").executes(ctx -> SelfTest.defeat(ctx.getSource())))
                        .then(method_9247("daily").executes(ctx -> SelfTest.daily(ctx.getSource())))
                        .then(method_9247("extreme").executes(ctx -> SelfTest.extreme(ctx.getSource())))
                        .then(method_9247("resume").executes(ctx -> SelfTest.resumeSetup(ctx.getSource())))
                        .then(method_9247("persisted").executes(ctx -> SelfTest.persisted(ctx.getSource())))
                        .then(method_9247("ranked").executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.ranked(ctx.getSource())))
                        .then(method_9247("rankedtimer").executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.rankedTimers(ctx.getSource())))
                        .then(method_9247("trainers").executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.trainers(ctx.getSource())))
                        .then(method_9247("towers").executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.towers(ctx.getSource())))
                        .then(method_9247("season").executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.season(ctx.getSource())))
                        .then(method_9247("rankedstorage").executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.storage(ctx.getSource())))
                        .then(method_9247("rankedpersisted").executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.storagePersisted(ctx.getSource())))
                        .then(method_9247("battlespersisted").executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.persisted(ctx.getSource())))
                        .then(method_9247("clientscreens").then(method_9244("joueur", StringArgumentType.word())
                                .executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.clientScreens(ctx.getSource(), StringArgumentType.getString(ctx, "joueur")))))
                        .then(method_9247("multi")
                                .then(method_9247("lobby").executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.multiLobby(ctx.getSource())))
                                .then(method_9247("combat").executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.multiCombat(ctx.getSource())))
                                .then(method_9247("check").executes(ctx -> fr.cobblepulse.battles.BattlesSelfTest.multiCheck(ctx.getSource()))))
                        .then(method_9247("report").executes(ctx -> SelfTest.report(ctx.getSource())))));
        d.register(method_9247("bt").requires(Perms.playerReq(Perms.USE)).executes(ctx -> player(ctx, Menus::main)).redirect(root));
    }

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> bpOp(String op) {
        return method_9247(op).then(method_9244("joueur", StringArgumentType.word()).suggests(KNOWN_PLAYERS)
                .then(method_9244("montant", LongArgumentType.longArg(0)).executes(ctx -> {
                    String name = StringArgumentType.getString(ctx, "joueur");
                    long amount = LongArgumentType.getLong(ctx, "montant");
                    PlayerData pd = PlayerStore.byName(name);
                    if (pd == null) {
                        Msg.send(ctx.getSource(), "general.player_not_found", "player", name);
                        return 0;
                    }
                    switch (op) {
                        case "give" -> BattlePoints.give(pd, amount);
                        case "take" -> pd.bp = Math.max(0, pd.bp - amount);
                        default -> pd.bp = amount;
                    }
                    PlayerStore.save(pd);
                    Msg.send(ctx.getSource(), "admin.bp_done", "player", pd.name, "bp", pd.bp);
                    return 1;
                })));
    }

    // ------------------------------------------------------------------ PNJ

    private static void npcSpawn(class_3222 p, FloorEntry fe) {
        NPCEntity npc = TrainerNpcs.spawnFloor(p.field_13995, fe, Loc.of(p));
        Msg.send(p, npc != null ? "admin.npc_spawned" : "admin.npc_spawn_failed", "floor", fe.floor);
    }

    private static void npcSetTp(class_3222 p, FloorEntry fe) {
        fe.arrival = Loc.of(p);
        TowerConfig.saveFloor(fe);
        Msg.send(p, "admin.settp_done", "floor", fe.floor, "loc", fe.arrival.pretty());
    }

    private static void npcRemove(class_3222 p, FloorEntry fe) {
        TrainerNpcs.remove(p.field_13995, fe.npcUuid, fe.npcLocation);
        fe.npcUuid = null;
        fe.npcLocation = null;
        TowerConfig.saveFloor(fe);
        Msg.send(p, "admin.npc_removed", "floor", fe.floor);
    }

    // ------------------------------------------------------------------ Tours secondaires

    public static int towerCreate(class_2168 src, String id, int floors, String name) {
        fr.cobblepulse.battletower.data.TowerData t = TowerConfig.create(id, name, floors);
        if (t == null) {
            Msg.send(src, "admin.tower_create_failed", "id", id);
            return 0;
        }
        Msg.send(src, "admin.tower_created", "id", t.id, "tower", TowerConfig.name(t), "floors", TowerConfig.size(t));
        return 1;
    }

    private static int towerEdit(class_2168 src, String id, java.util.function.Consumer<fr.cobblepulse.battletower.data.TowerData> change) {
        fr.cobblepulse.battletower.data.TowerData t = TowerConfig.tower(id);
        if (t == null || TowerConfig.isMain(t)) {
            Msg.send(src, "tower.unknown_tower", "tower", id);
            return 0;
        }
        change.accept(t);
        Msg.send(src, "admin.tower_updated", "id", t.id, "tower", TowerConfig.name(t), "floors", TowerConfig.size(t));
        return 1;
    }

    /** Supprime une tour secondaire et ses PNJ (refuse si une ascension y est en cours). */
    public static boolean towerDelete(class_2168 src, String id) {
        fr.cobblepulse.battletower.data.TowerData t = TowerConfig.tower(id);
        if (t == null || TowerConfig.isMain(t)) {
            Msg.send(src, "tower.unknown_tower", "tower", id);
            return false;
        }
        for (RunState r : TowerManager.runs()) {
            if (!r.daily && t.id.equals(r.tower)) {
                Msg.send(src, "admin.tower_busy", "tower", TowerConfig.name(t));
                return false;
            }
        }
        for (FloorEntry fe : t.floors) TrainerNpcs.remove(src.method_9211(), fe.npcUuid, fe.npcLocation);
        TowerConfig.delete(t.id);
        Msg.send(src, "admin.tower_deleted", "tower", TowerConfig.name(t));
        return true;
    }

    /** /battletower npc edit sans argument : PNJ vise (6 blocs). */
    private static void npcEditTargeted(class_3222 p) {
        class_1297 target = lookedAt(p, 6);
        if (target == null || !TrainerNpcs.isOurs(target)) {
            Msg.send(p, "admin.no_target");
            return;
        }
        int floor = TrainerNpcs.floorOf(target);
        if (floor > 0) EditorService.openFloor(p, TrainerNpcs.towerOf(target), floor);
        else if (target.method_5752().contains(TrainerNpcs.TAG_BOSS)) EditorService.openBoss(p, DailyBoss.currentId());
        else Msg.send(p, "admin.no_target");
    }

    public static class_1297 lookedAt(class_3222 p, double range) {
        class_243 eye = p.method_33571();
        class_243 look = p.method_5828(1.0f);
        class_243 end = eye.method_1019(look.method_1021(range));
        class_238 box = p.method_5829().method_18804(look.method_1021(range)).method_1014(1.0);
        class_1297 best = null;
        double bestDist = range * range;
        for (class_1297 e : p.method_37908().method_8333(p, box, e -> e instanceof NPCEntity)) {
            class_238 eb = e.method_5829().method_1014(0.3);
            var hit = eb.method_992(eye, end);
            if (eb.method_1006(eye) || hit.isPresent()) {
                double dist = hit.map(eye::method_1025).orElse(0.0);
                if (dist < bestDist) {
                    bestDist = dist;
                    best = e;
                }
            }
        }
        return best;
    }

    public static void spawnBossNpc(class_3222 p) {
        TowerData d = TowerConfig.data();
        TrainerNpcs.remove(p.field_13995, d.bossNpcUuid, d.bossNpcLocation);
        TrainerSpec t = DailyBoss.current();
        String name = t == null ? "&c&lBoss du Jour" : "&c&l" + t.display();
        NPCEntity npc = TrainerNpcs.spawn(p.field_13995, Loc.of(p), name, t == null ? "builtin:champion" : t.skin, TrainerNpcs.TAG_BOSS);
        if (npc != null) {
            d.bossNpcUuid = npc.method_5667().toString();
            d.bossNpcLocation = Loc.of(p);
            TowerConfig.saveFloors();
            Msg.send(p, "admin.boss_spawned");
        }
    }

    private static int bossCreate(class_2168 src, String rawId) {
        String id = rawId.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_\\-]", "");
        if (id.isEmpty() || TowerConfig.bosses().bosses.containsKey(id)) {
            Msg.send(src, "admin.boss_exists", "id", id);
            return 0;
        }
        TrainerSpec t = new TrainerSpec();
        t.name = rawId;
        t.title = "Boss";
        t.ai = "EXTREME";
        t.skin = "builtin:champion";
        TowerConfig.bosses().bosses.put(id, t);
        TowerConfig.saveBosses();
        Msg.send(src, "admin.boss_created", "id", id);
        if (src.method_44023() != null) EditorService.openBoss(src.method_44023(), id);
        return 1;
    }

    private static int bossDelete(class_2168 src, String id) {
        if (TowerConfig.bosses().bosses.remove(id.toLowerCase(Locale.ROOT)) == null) {
            Msg.send(src, "admin.boss_unknown", "id", id);
            return 0;
        }
        TowerConfig.saveBosses();
        Msg.send(src, "admin.boss_deleted", "id", id);
        return 1;
    }

    // ------------------------------------------------------------------ Boutique

    private static void shopSpawn(class_3222 p) {
        NPCEntity npc = TrainerNpcs.spawn(p.field_13995, Loc.of(p), Cfg.shop.str("menu.npc_name", "&6Marchand de la Tour"),
                Cfg.shop.str("menu.npc_skin", "builtin:shopkeeper"), TrainerNpcs.TAG_SHOP);
        if (npc == null) return;
        TowerData.ShopNpc s = new TowerData.ShopNpc();
        s.uuid = npc.method_5667().toString();
        s.location = Loc.of(p);
        TowerConfig.data().shops.add(s);
        TowerConfig.saveFloors();
        Msg.send(p, "admin.shop_spawned");
    }

    private static void shopRemove(class_3222 p) {
        class_1297 target = lookedAt(p, 6);
        if (target == null || !target.method_5752().contains(TrainerNpcs.TAG_SHOP)) {
            Msg.send(p, "admin.no_target");
            return;
        }
        String id = target.method_5667().toString();
        target.method_31472();
        TowerConfig.data().shops.removeIf(s -> id.equals(s.uuid));
        TowerConfig.saveFloors();
        Msg.send(p, "admin.shop_removed");
    }

    // ------------------------------------------------------------------ Staff

    private static int inspect(class_2168 src, String name) {
        PlayerData d = PlayerStore.byName(name);
        if (d == null) {
            Msg.send(src, "general.player_not_found", "player", name);
            return 0;
        }
        RunState r = TowerManager.run(java.util.UUID.fromString(d.uuid));
        Msg.send(src, "staff.inspect", "player", d.name, "bp", d.bp, "floor", d.maxFloor, "completions", d.completions,
                "wins", d.totalWins, "losses", d.totalLosses, "cooldown", TimeFmt.duration(TowerManager.cooldownLeft(d)),
                "run", r == null ? "-" : (r.daily ? "Boss du Jour" : "etage " + r.floor) + " (" + r.phase + ")",
                "daily", DailyBoss.attemptedToday(d) ? "oui" : "non");
        return 1;
    }
}
