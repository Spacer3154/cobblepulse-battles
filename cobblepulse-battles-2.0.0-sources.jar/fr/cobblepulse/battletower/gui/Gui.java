package fr.cobblepulse.battletower.gui;

import fr.cobblepulse.battletower.core.ItemBuilder;
import fr.cobblepulse.battletower.core.Scheduler;
import fr.cobblepulse.battletower.core.TextUtil;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1277;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;

/**
 * Menu pilote par le serveur. Avec le mod cote client, il s'affiche comme un ecran CobblePulse (cartes, barre d'actions,
 * recherche, saisie integree, voir {@link Screens}) ; sinon comme un coffre verrouille. Dans les deux cas, chaque clic
 * est transforme en action cote serveur et aucun objet ne peut etre deplace.
 */
public class Gui {
    public record Click(class_1713 type, int button) {
        public boolean right() {
            return type == class_1713.field_7790 && button == 1;
        }

        public boolean left() {
            return type == class_1713.field_7790 && button == 0;
        }

        public boolean shift() {
            return type == class_1713.field_7794;
        }
    }

    @FunctionalInterface
    public interface Handler {
        void click(class_3222 player, Click click);
    }

    final int rows;
    final class_2561 title;
    class_1277 container;
    final Map<Integer, Handler> handlers = new HashMap<>();
    Consumer<class_3222> onClose;
    /** Liste (menus pagines) : l'ecran client affiche une grille unique avec recherche. */
    boolean list;
    boolean afterBattle;
    /** Joueur dont l'ecran client affiche ce menu (rafraichi a chaque modification). */
    class_3222 shownTo;
    boolean resendQueued;
    private int tickEvery;
    private Consumer<Gui> ticker;
    private Scheduler.Task tickTask;

    public Gui(int rows, String legacyTitle) {
        this(rows, TextUtil.legacy(legacyTitle));
    }

    public Gui(int rows, class_2561 title) {
        this.rows = Math.max(1, Math.min(6, rows));
        this.title = title;
        this.container = new class_1277(this.rows * 9);
    }

    public int size() {
        return container.method_5439();
    }

    /** Agrandit le menu au-dela de 54 cases (ecran client uniquement : listes completes sans pagination). */
    public Gui grow(int slots) {
        if (slots <= size()) return this;
        class_1277 c = new class_1277(slots);
        for (int i = 0; i < container.method_5439(); i++) c.method_5447(i, container.method_5438(i));
        container = c;
        return this;
    }

    public int rows() {
        return rows;
    }

    /** Ecran client : attendre la fin de l'animation du combat Cobblemon avant d'afficher (fenetre de butin). */
    public Gui afterBattle(boolean wait) {
        this.afterBattle = wait;
        return this;
    }

    public Gui list(boolean list) {
        this.list = list;
        return this;
    }

    public Gui set(int slot, class_1799 item) {
        return set(slot, item, null);
    }

    public Gui set(int slot, class_1799 item, Handler handler) {
        if (slot < 0 || slot >= size()) return this;
        container.method_5447(slot, item == null ? class_1799.field_8037 : item);
        if (handler != null) handlers.put(slot, handler);
        else handlers.remove(slot);
        if (shownTo != null) Screens.queueRefresh(this);
        return this;
    }

    /** Action simple (tout type de clic). */
    public Gui button(int slot, class_1799 item, Consumer<class_3222> action) {
        return set(slot, item, (p, c) -> action.accept(p));
    }

    /** Action avec type de clic. */
    public Gui button(int slot, class_1799 item, Handler handler) {
        return set(slot, item, handler);
    }

    public Handler handler(int slot) {
        return handlers.get(slot);
    }

    public class_1799 get(int slot) {
        return container.method_5438(slot);
    }

    public Gui fill(class_1799 filler) {
        for (int i = 0; i < size(); i++) {
            if (container.method_5438(i).method_7960()) container.method_5447(i, filler.method_7972());
        }
        return this;
    }

    public Gui border() {
        class_1799 pane = pane();
        for (int i = 0; i < size(); i++) {
            int r = i / 9;
            int c = i % 9;
            if ((r == 0 || r == rows - 1 || c == 0 || c == 8) && container.method_5438(i).method_7960()) container.method_5447(i, pane.method_7972());
        }
        return this;
    }

    /** Mise a jour periodique tant que le menu est affiche (compte a rebours, progression...). */
    public Gui every(int ticks, Consumer<Gui> update) {
        this.tickEvery = Math.max(1, ticks);
        this.ticker = update;
        return this;
    }

    private void startTicker(class_3222 p) {
        if (ticker == null || tickTask != null) return;
        tickTask = Scheduler.repeat(tickEvery, tickEvery, () -> {
            boolean visible = shownTo == p || p.field_7512 instanceof LockedMenu lm && lm.gui() == this;
            if (!visible || p.method_14239()) {
                if (tickTask != null) tickTask.cancel();
                tickTask = null;
                return;
            }
            ticker.accept(this);
        });
    }

    public Gui onClose(Consumer<class_3222> c) {
        this.onClose = c;
        return this;
    }

    /** Cases interieures (hors bordure) d'un menu de {@code rows} lignes. */
    public static int[] innerSlots(int rows) {
        java.util.List<Integer> s = new java.util.ArrayList<>();
        for (int r = 1; r < rows - 1; r++) for (int c = 1; c < 8; c++) s.add(r * 9 + c);
        int[] out = new int[s.size()];
        for (int i = 0; i < out.length; i++) out[i] = s.get(i);
        return out;
    }

    public static class_1799 pane() {
        return ItemBuilder.of(class_1802.field_8871).name(" ").hideExtra().build();
    }

    public void open(class_3222 player) {
        if (Screens.enabled(player)) {
            Screens.show(player, this);
            startTicker(player);
            return;
        }
        Screens.forget(player);
        if (size() > rows * 9) {
            class_1277 c = new class_1277(rows * 9);
            for (int i = 0; i < rows * 9; i++) c.method_5447(i, container.method_5438(i));
            container = c;
        }
        player.method_17355(new class_747((id, inv, p) -> new LockedMenu(id, inv, this), title));
        startTicker(player);
    }

    /** Ferme le menu du joueur (coffre ou ecran client). */
    public static void close(class_3222 player) {
        player.method_7346();
        Screens.close(player);
    }

    /** Ouvre au tick suivant (a utiliser depuis un clic pour eviter la reentrance). */
    public void openLater(class_3222 player) {
        Scheduler.next(() -> {
            if (!player.method_14239()) open(player);
        });
    }

    void handleClick(class_3222 player, int slot, Click click) {
        Handler h = handlers.get(slot);
        if (h != null) Scheduler.next(() -> {
            if (!player.method_14239()) h.click(player, click);
        });
    }
}
