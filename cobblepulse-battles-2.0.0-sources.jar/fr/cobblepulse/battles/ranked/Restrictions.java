package fr.cobblepulse.battles.ranked;

import fr.cobblepulse.battletower.config.TomlFile;
import fr.cobblepulse.battletower.core.Msg;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Restrictions pendant la file d'attente et pendant un match (restrictions.toml). */
public final class Restrictions {
    private static final Map<UUID, Long> LAST_WARN = new ConcurrentHashMap<>();
    /** Auto-tests : nombre de commandes bloquees. */
    public static final java.util.concurrent.atomic.AtomicInteger BLOCKED = new java.util.concurrent.atomic.AtomicInteger();

    private Restrictions() {}

    /** Section active pour le joueur : "match", "file" ou null. */
    static String section(UUID uuid) {
        if (MatchManager.inMatch(uuid)) return "match";
        if (RankedQueue.queued(uuid)) return "file";
        return null;
    }

    public static boolean blocked(class_1657 p, String rule) {
        if (!(p instanceof class_3222 sp) || RankedConfig.restrictions == null) return false;
        String sec = section(sp.method_5667());
        if (sec == null) return false;
        TomlFile t = RankedConfig.restrictions;
        boolean b = t.b(sec + "." + rule, false);
        if (b) warn(sp, sec);
        return b;
    }

    private static void warn(class_3222 p, String sec) {
        long now = System.currentTimeMillis();
        Long last = LAST_WARN.get(p.method_5667());
        if (last != null && now - last < 2000) return;
        LAST_WARN.put(p.method_5667(), now);
        Msg.send(p, "file".equals(sec) ? "ranked.restricted_queue" : "ranked.restricted_match");
    }

    /** Appele par le mixin de commandes. */
    public static boolean blockCommand(class_3222 p, String command) {
        if (RankedConfig.restrictions == null) return false;
        String sec = section(p.method_5667());
        if (sec == null) return false;
        String c = command.startsWith("/") ? command.substring(1) : command;
        String root = c.split(" ", 2)[0].toLowerCase(Locale.ROOT);
        int colon = root.indexOf(':');
        if (colon >= 0) root = root.substring(colon + 1);
        // les commandes de la Ranked restent toujours possibles (quitter la file, accepter...)
        if (root.equals("ranked") || root.equals("amical") || root.equals("battles") || root.equals("combats")) return false;
        for (String b : RankedConfig.restrictions.list(sec + ".commandes_bloquees")) {
            if (root.equalsIgnoreCase(b.trim())) {
                Msg.send(p, "ranked.command_blocked", "command", root);
                BLOCKED.incrementAndGet();
                return true;
            }
        }
        return false;
    }

    static boolean isPcBlock(net.minecraft.class_2680 state) {
        String id = class_7923.field_41175.method_10221(state.method_26204()).toString();
        return id.equals("cobblemon:pc");
    }

    public static void register() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (level.method_8608()) return class_1269.field_5811;
            var state = level.method_8320(hit.method_17777());
            if (isPcBlock(state) && blocked(player, "pc")) return class_1269.field_5814;
            class_1799 inHand = player.method_5998(hand);
            if (inHand.method_7909() instanceof class_1747 && blocked(player, "poser_blocs")) return class_1269.field_5814;
            if (blocked(player, "interagir_blocs")) return class_1269.field_5814;
            return class_1269.field_5811;
        });
        PlayerBlockBreakEvents.BEFORE.register((level, player, pos, state, be) -> !blocked(player, "casser_blocs"));
        UseItemCallback.EVENT.register((player, level, hand) -> {
            class_1799 st = player.method_5998(hand);
            if (!level.method_8608() && blocked(player, "utiliser_objets")) return class_1271.method_22431(st);
            return class_1271.method_22430(st);
        });
        UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            if (!level.method_8608() && blocked(player, "interagir_entites")) return class_1269.field_5814;
            return class_1269.field_5811;
        });
        AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            if (!level.method_8608() && blocked(player, "attaquer")) return class_1269.field_5814;
            return class_1269.field_5811;
        });
    }
}
