package fr.cobblepulse.battles.ranked;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import fr.cobblepulse.battles.hub.Hub;
import fr.cobblepulse.battletower.core.Loc;
import fr.cobblepulse.battletower.core.Msg;
import fr.cobblepulse.battletower.core.Perms;
import fr.cobblepulse.battletower.core.TimeFmt;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_3222;

/** /ranked, /amical, /battles. */
public final class RankedCommands {
    private RankedCommands() {}

    static com.mojang.brigadier.suggestion.SuggestionProvider<class_2168> formats() {
        return (c, b) -> class_2172.method_9265(RankedConfig.FORMATS, b);
    }

    static com.mojang.brigadier.suggestion.SuggestionProvider<class_2168> arenas() {
        return (c, b) -> class_2172.method_9264(Arenas.all().stream().map(a -> a.name), b);
    }

    static com.mojang.brigadier.suggestion.SuggestionProvider<class_2168> players() {
        return (c, b) -> class_2172.method_9264(RankedStore.all().stream().map(p -> p.name), b);
    }

    public static void register(CommandDispatcher<class_2168> d) {
        d.register(class_2170.method_9247("battles").executes(c -> hub(c)));
        d.register(class_2170.method_9247("combats").executes(c -> hub(c)));
        d.register(class_2170.method_9247("amical").requires(Perms.playerReq(Ranked.PERM_CASUAL))
                .executes(c -> {
                    RankedMenus.main(c.getSource().method_9207());
                    return 1;
                })
                .then(class_2170.method_9244("format", StringArgumentType.word()).suggests(formats()).executes(c ->
                        RankedQueue.join(c.getSource().method_9207(), StringArgumentType.getString(c, "format"), false) ? 1 : 0)));
        var admin = class_2170.method_9247("admin").requires(Perms.adminReq(Ranked.PERM_ADMIN))
                .executes(c -> {
                    RankedMenus.admin(c.getSource().method_9207());
                    return 1;
                })
                .then(class_2170.method_9247("arene")
                        .then(class_2170.method_9247("liste").executes(c -> {
                            for (Arenas.Arena a : Arenas.all()) {
                                Msg.send(c.getSource(), "ranked.arena_line", "name", a.name, "status", Msg.formatBare(a.ready() ? (Arenas.busy(a) ? "ranked.arena_busy" : "ranked.arena_free") : "ranked.arena_incomplete"));
                            }
                            return 1;
                        }))
                        .then(class_2170.method_9247("creer").then(class_2170.method_9244("nom", StringArgumentType.word()).executes(c -> {
                            Arenas.Arena a = Arenas.create(StringArgumentType.getString(c, "nom"));
                            a.pos1 = Loc.of(c.getSource().method_9207());
                            Arenas.save();
                            Msg.send(c.getSource(), "ranked.arena_created", "name", a.name);
                            return 1;
                        })))
                        .then(arenaPos("pos1", 1))
                        .then(arenaPos("pos2", 2))
                        .then(arenaPos("sortie", 3))
                        .then(class_2170.method_9247("supprimer").then(class_2170.method_9244("nom", StringArgumentType.word()).suggests(arenas()).executes(c -> {
                            boolean ok = Arenas.remove(StringArgumentType.getString(c, "nom"));
                            Msg.send(c.getSource(), ok ? "ranked.arena_deleted" : "ranked.arena_unknown", "name", StringArgumentType.getString(c, "nom"));
                            return ok ? 1 : 0;
                        })))
                        .then(class_2170.method_9247("tp").then(class_2170.method_9244("nom", StringArgumentType.word()).suggests(arenas()).executes(c -> {
                            Arenas.Arena a = Arenas.get(StringArgumentType.getString(c, "nom"));
                            if (a == null || a.pos1 == null) return 0;
                            a.pos1.teleport(c.getSource().method_9207());
                            return 1;
                        }))))
                .then(class_2170.method_9247("saison")
                        .then(class_2170.method_9247("info").executes(c -> {
                            Msg.send(c.getSource(), "ranked.season_info", "season", Seasons.describe(), "end", Seasons.endText(),
                                    "time", TimeFmt.duration(Seasons.remainingMs()));
                            return 1;
                        }))
                        .then(class_2170.method_9247("changer").executes(c -> {
                            Seasons.forceRotate();
                            Msg.send(c.getSource(), "ranked.season_rotated", "season", Seasons.describe());
                            return 1;
                        })))
                .then(class_2170.method_9247("elo")
                        .then(eloCmd("definir", false))
                        .then(eloCmd("ajouter", true)))
                .then(class_2170.method_9247("bannir").then(class_2170.method_9244("joueur", StringArgumentType.word()).suggests(players())
                        .then(class_2170.method_9244("minutes", IntegerArgumentType.integer(1)).executes(c -> {
                            RankedProfile p = RankedStore.byName(StringArgumentType.getString(c, "joueur"));
                            if (p == null) return notFound(c);
                            p.banUntil = System.currentTimeMillis() + IntegerArgumentType.getInteger(c, "minutes") * 60_000L;
                            p.banReason = "staff";
                            RankedStore.mark(p);
                            RankedQueue.leave(UUID.fromString(p.uuid));
                            Msg.send(c.getSource(), "ranked.banned_done", "player", p.name, "minutes", IntegerArgumentType.getInteger(c, "minutes"));
                            return 1;
                        }))))
                .then(class_2170.method_9247("debannir").then(class_2170.method_9244("joueur", StringArgumentType.word()).suggests(players()).executes(c -> {
                    RankedProfile p = RankedStore.byName(StringArgumentType.getString(c, "joueur"));
                    if (p == null) return notFound(c);
                    p.banUntil = 0;
                    p.flees = 0;
                    RankedStore.mark(p);
                    Msg.send(c.getSource(), "ranked.unbanned_done", "player", p.name);
                    return 1;
                })))
                .then(class_2170.method_9247("fin").then(class_2170.method_9244("joueur", StringArgumentType.word()).executes(c -> {
                    RankedProfile p = RankedStore.byName(StringArgumentType.getString(c, "joueur"));
                    boolean ok = p != null && MatchManager.forceEnd(UUID.fromString(p.uuid));
                    Msg.send(c.getSource(), ok ? "ranked.force_end_done" : "ranked.force_end_none", "player", StringArgumentType.getString(c, "joueur"));
                    return ok ? 1 : 0;
                })))
                .then(class_2170.method_9247("reset").then(class_2170.method_9244("joueur", StringArgumentType.word()).suggests(players()).executes(c -> {
                    RankedProfile p = RankedStore.byName(StringArgumentType.getString(c, "joueur"));
                    if (p == null) return notFound(c);
                    p.formats.clear();
                    p.history.clear();
                    p.flees = 0;
                    p.banUntil = 0;
                    RankedStore.mark(p);
                    Msg.send(c.getSource(), "ranked.reset_done", "player", p.name);
                    return 1;
                })))
                .then(class_2170.method_9247("recharger").executes(c -> {
                    Ranked.reload();
                    Msg.send(c.getSource(), "ranked.reloaded");
                    return 1;
                }));
        d.register(class_2170.method_9247("ranked").requires(Perms.playerReq(Ranked.PERM_RANKED))
                .executes(c -> {
                    RankedMenus.main(c.getSource().method_9207());
                    return 1;
                })
                .then(class_2170.method_9247("file").then(class_2170.method_9244("format", StringArgumentType.word()).suggests(formats())
                        .executes(c -> RankedQueue.join(c.getSource().method_9207(), StringArgumentType.getString(c, "format"), true) ? 1 : 0)
                        .then(class_2170.method_9247("amical").executes(c -> RankedQueue.join(c.getSource().method_9207(), StringArgumentType.getString(c, "format"), false) ? 1 : 0))
                        .then(class_2170.method_9247("classe").executes(c -> RankedQueue.join(c.getSource().method_9207(), StringArgumentType.getString(c, "format"), true) ? 1 : 0))))
                .then(class_2170.method_9247("quitter").executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    Msg.send(p, RankedQueue.leave(p.method_5667()) ? "ranked.left_queue" : "ranked.not_queued");
                    return 1;
                }))
                .then(class_2170.method_9247("accepter").executes(c -> {
                    MatchManager.accept(c.getSource().method_9207());
                    return 1;
                }))
                .then(class_2170.method_9247("refuser").executes(c -> {
                    MatchManager.decline(c.getSource().method_9207());
                    return 1;
                }))
                .then(class_2170.method_9247("top").executes(c -> {
                    RankedMenus.leaderboard(c.getSource().method_9207(), "simple");
                    return 1;
                }).then(class_2170.method_9244("format", StringArgumentType.word()).suggests(formats()).executes(c -> {
                    RankedMenus.leaderboard(c.getSource().method_9207(), StringArgumentType.getString(c, "format"));
                    return 1;
                })))
                .then(class_2170.method_9247("profil").executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    RankedMenus.profile(p, p.method_5667());
                    return 1;
                }).then(class_2170.method_9244("joueur", StringArgumentType.word()).suggests(players()).executes(c -> {
                    RankedProfile p = RankedStore.byName(StringArgumentType.getString(c, "joueur"));
                    if (p == null) return notFound(c);
                    RankedMenus.profile(c.getSource().method_9207(), UUID.fromString(p.uuid));
                    return 1;
                })))
                .then(class_2170.method_9247("missions").executes(c -> {
                    RankedMenus.missions(c.getSource().method_9207());
                    return 1;
                }))
                .then(class_2170.method_9247("historique").executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    RankedMenus.history(p, RankedStore.get(p));
                    return 1;
                }))
                .then(class_2170.method_9247("rangs").executes(c -> {
                    RankedMenus.ranks(c.getSource().method_9207());
                    return 1;
                }))
                .then(admin));
    }

    private static int hub(CommandContext<class_2168> c) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        Hub.open(c.getSource().method_9207());
        return 1;
    }

    private static int notFound(CommandContext<class_2168> c) {
        Msg.send(c.getSource(), "general.player_not_found", "player", StringArgumentType.getString(c, "joueur"));
        return 0;
    }

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> arenaPos(String lit, int which) {
        return class_2170.method_9247(lit).then(class_2170.method_9244("nom", StringArgumentType.word()).suggests(arenas()).executes(c -> {
            Arenas.Arena a = Arenas.get(StringArgumentType.getString(c, "nom"));
            if (a == null) {
                Msg.send(c.getSource(), "ranked.arena_unknown", "name", StringArgumentType.getString(c, "nom"));
                return 0;
            }
            Loc l = Loc.of(c.getSource().method_9207());
            if (which == 1) a.pos1 = l;
            else if (which == 2) a.pos2 = l;
            else a.exit = l;
            Arenas.save();
            Msg.send(c.getSource(), "ranked.arena_pos_set", "name", a.name, "what", lit);
            return 1;
        }));
    }

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> eloCmd(String lit, boolean add) {
        return class_2170.method_9247(lit).then(class_2170.method_9244("joueur", StringArgumentType.word()).suggests(players())
                .then(class_2170.method_9244("format", StringArgumentType.word()).suggests(formats())
                        .then(class_2170.method_9244("valeur", IntegerArgumentType.integer(-5000, 10000)).executes(c -> {
                            RankedProfile p = RankedStore.byName(StringArgumentType.getString(c, "joueur"));
                            if (p == null) return notFound(c);
                            String f = RankedConfig.normalizeFormat(StringArgumentType.getString(c, "format"));
                            if (f == null) return 0;
                            RankedProfile.FormatStats st = p.stats(f);
                            int v = IntegerArgumentType.getInteger(c, "valeur");
                            st.elo = Math.max(RankedConfig.floorElo(), add ? st.elo + v : v);
                            st.peak = Math.max(st.peak, st.elo);
                            RankedStore.mark(p);
                            Msg.send(c.getSource(), "ranked.elo_set", "player", p.name, "format", f, "elo", st.elo);
                            return 1;
                        }))));
    }
}
