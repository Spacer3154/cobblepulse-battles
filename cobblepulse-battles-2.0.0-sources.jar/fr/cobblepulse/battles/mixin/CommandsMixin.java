package fr.cobblepulse.battles.mixin;

import com.mojang.brigadier.ParseResults;
import fr.cobblepulse.battles.ranked.Restrictions;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Commandes interdites pendant la file et les matchs de la Ranked (restrictions.toml). Les commandes tapees par les
 * joueurs (signees ou non) et celles lancees par performPrefixedCommand passent toutes par performCommand.
 */
@Mixin(class_2170.class)
public abstract class CommandsMixin {
    @Inject(method = "performCommand", at = @At("HEAD"), cancellable = true)
    private void cpbattles$restrict(ParseResults<class_2168> parse, String command, CallbackInfo ci) {
        class_2168 source = parse == null ? null : parse.getContext().getSource();
        if (source != null && source.method_9228() instanceof class_3222 p && Restrictions.blockCommand(p, command)) ci.cancel();
    }
}
