package fr.cobblepulse.battles.tool;

import com.cobblemon.mod.common.entity.npc.NPCEntity;
import fr.cobblepulse.battles.trainers.TrainerCommands;
import fr.cobblepulse.battles.trainers.TrainerMenus;
import fr.cobblepulse.battles.trainers.WorldTrainers;
import fr.cobblepulse.battletower.Battletower;
import fr.cobblepulse.battletower.core.Loc;
import fr.cobblepulse.battletower.core.Msg;
import fr.cobblepulse.battletower.core.Perms;
import fr.cobblepulse.battletower.gui.ChatInput;
import fr.cobblepulse.battletower.menu.AdminMenus;
import fr.cobblepulse.battletower.net.EditorService;
import fr.cobblepulse.battletower.npc.TrainerNpcs;
import fr.cobblepulse.battletower.tower.TowerManager;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import java.util.List;

/**
 * Objet d'administration « Editeur de PNJ » : clic droit sur un PNJ de CobblePulse-Battles (etage de la Tour, Boss du
 * Jour, boutique, dresseur du monde) pour ouvrir son editeur ; sur un bloc pour poser un nouveau dresseur ; dans le vide
 * pour la liste des dresseurs. Reserve au staff.
 */
public final class NpcEditorTool {
    public static final class_2960 ID = class_2960.method_60655(Battletower.MOD_ID, "editeur_pnj");
    public static class_1792 ITEM;

    private NpcEditorTool() {}

    public static void register() {
        ITEM = class_2378.method_10230(class_7923.field_41178, ID, new EditorItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904)));
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41063).register(e -> e.method_45421(ITEM));
    }

    public static boolean is(class_1799 st) {
        return ITEM != null && st != null && st.method_31574(ITEM);
    }

    public static boolean allowed(class_3222 p) {
        return Perms.admin(p, TrainerCommands.PERM_ADMIN) || Perms.isAdmin(p);
    }

    public static class_1799 stack() {
        return new class_1799(ITEM);
    }

    public static void give(class_3222 p) {
        class_1799 st = stack();
        if (!p.method_31548().method_7394(st)) p.method_7328(st, false);
        Msg.send(p, "tool.given");
    }

    /** Clic droit sur un PNJ avec l'outil (le PNJ n'est pas « utilise » : pas de combat ni de boutique). */
    public static void onNpc(class_3222 p, NPCEntity npc) {
        if (!allowed(p)) {
            Msg.send(p, "tool.no_permission");
            return;
        }
        if (!TrainerNpcs.isOurs(npc)) {
            Msg.send(p, "tool.not_ours");
            return;
        }
        if (WorldTrainers.isWorld(npc)) {
            WorldTrainers.WorldTrainer w = WorldTrainers.of(npc);
            if (w == null) Msg.send(p, "tool.not_ours");
            else EditorService.openWorld(p, w.id);
            return;
        }
        if (npc.method_5752().contains(TrainerNpcs.TAG_BOSS)) {
            String boss = TowerManager.state().currentBossId;
            if (boss == null || boss.isBlank()) AdminMenus.bosses(p);
            else EditorService.openBoss(p, boss);
            return;
        }
        if (npc.method_5752().contains(TrainerNpcs.TAG_SHOP)) {
            AdminMenus.panel(p);
            return;
        }
        int floor = TrainerNpcs.floorOf(npc);
        if (floor > 0) EditorService.openFloor(p, TrainerNpcs.towerOf(npc), floor);
        else Msg.send(p, "tool.not_ours");
    }

    public static void onAir(class_3222 p) {
        if (!allowed(p)) {
            Msg.send(p, "tool.no_permission");
            return;
        }
        TrainerMenus.list(p);
    }

    /** Clic droit sur un bloc : nouveau dresseur pose sur ce bloc, tourne vers le joueur. */
    public static void onBlock(class_3222 p, class_2338 clicked, class_2350 face) {
        if (!allowed(p)) {
            Msg.send(p, "tool.no_permission");
            return;
        }
        class_2338 at = face == class_2350.field_11036 || face == null ? clicked.method_10084() : clicked.method_10093(face);
        Loc loc = new Loc(p.method_51469().method_27983().method_29177().toString(), at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5,
                net.minecraft.class_3532.method_15393(p.method_36454() + 180f), 0f);
        ChatInput.ask(p, "trainer.ask_id", id -> {
            WorldTrainers.WorldTrainer w = WorldTrainers.create(p, id, loc);
            if (w == null) Msg.send(p, "trainer.create_failed", "id", id);
            else {
                Msg.send(p, "trainer.created", "id", w.id);
                EditorService.openWorld(p, w.id);
            }
        }, () -> {
        });
    }

    static final class EditorItem extends class_1792 {
        EditorItem(class_1793 props) {
            super(props);
        }

        @Override
        public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
            class_1799 st = player.method_5998(hand);
            if (!level.method_8608() && player instanceof class_3222 sp) onAir(sp);
            return class_1271.method_29237(st, level.method_8608());
        }

        @Override
        public class_1269 method_7884(class_1838 ctx) {
            if (!ctx.method_8045().method_8608() && ctx.method_8036() instanceof class_3222 sp) onBlock(sp, ctx.method_8037(), ctx.method_8038());
            return class_1269.method_29236(ctx.method_8045().method_8608());
        }

        @Override
        public void method_7851(class_1799 stack, class_9635 context, List<class_2561> lines, class_1836 flag) {
            lines.add(class_2561.method_43471("item.cobblepulse_battles.editeur_pnj.npc").method_27692(class_124.field_1080));
            lines.add(class_2561.method_43471("item.cobblepulse_battles.editeur_pnj.block").method_27692(class_124.field_1080));
            lines.add(class_2561.method_43471("item.cobblepulse_battles.editeur_pnj.air").method_27692(class_124.field_1080));
            lines.add(class_2561.method_43471("item.cobblepulse_battles.editeur_pnj.staff").method_27692(class_124.field_1079));
        }
    }
}
