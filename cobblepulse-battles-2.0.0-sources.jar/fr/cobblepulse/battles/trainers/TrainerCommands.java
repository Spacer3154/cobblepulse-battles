package fr.cobblepulse.battles.trainers;

import com.cobblemon.mod.common.entity.npc.NPCEntity;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import fr.cobblepulse.battletower.core.Msg;
import fr.cobblepulse.battletower.core.Perms;
import fr.cobblepulse.battletower.data.PlayerData;
import fr.cobblepulse.battletower.net.EditorService;
import fr.cobblepulse.battletower.storage.PlayerStore;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3966;

/** /dresseur : gestion des dresseurs hors Tour ; /dresseurs : liste et progression. */
public final class TrainerCommands {
    public static final String PERM_USE = "cobblepulse.battles.trainers.use";
    public static final String PERM_ADMIN = "cobblepulse.battles.trainers.admin";

    private TrainerCommands() {}

    static com.mojang.brigadier.suggestion.SuggestionProvider<class_2168> ids() {
        return (ctx, b) -> class_2172.method_9264(WorldTrainers.all().stream().map(w -> w.id), b);
    }

    public static void register(CommandDispatcher<class_2168> d) {
        d.register(class_2170.method_9247("dresseurs").requires(Perms.playerReq(PERM_USE)).executes(c -> {
            TrainerMenus.list(c.getSource().method_9207());
            return 1;
        }));
        var root = class_2170.method_9247("dresseur").requires(Perms.adminReq(PERM_ADMIN))
                .executes(c -> {
                    TrainerMenus.list(c.getSource().method_9207());
                    return 1;
                })
                .then(class_2170.method_9247("liste").executes(c -> {
                    TrainerMenus.list(c.getSource().method_9207());
                    return 1;
                }))
                .then(class_2170.method_9247("outil").executes(c -> {
                    fr.cobblepulse.battles.tool.NpcEditorTool.give(c.getSource().method_9207());
                    return 1;
                }))
                .then(class_2170.method_9247("creer").then(class_2170.method_9244("id", StringArgumentType.word()).executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    String id = StringArgumentType.getString(c, "id");
                    WorldTrainers.WorldTrainer w = WorldTrainers.create(p, id);
                    if (w == null) Msg.send(p, "trainer.create_failed", "id", id);
                    else {
                        Msg.send(p, "trainer.created", "id", w.id);
                        EditorService.openWorld(p, w.id);
                    }
                    return w == null ? 0 : 1;
                })))
                .then(class_2170.method_9247("editer")
                        .executes(c -> edit(c, null))
                        .then(class_2170.method_9244("id", StringArgumentType.word()).suggests(ids()).executes(c -> edit(c, StringArgumentType.getString(c, "id")))))
                .then(class_2170.method_9247("deplacer").then(class_2170.method_9244("id", StringArgumentType.word()).suggests(ids()).executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    WorldTrainers.WorldTrainer w = WorldTrainers.get(StringArgumentType.getString(c, "id"));
                    if (w == null) return unknown(p, StringArgumentType.getString(c, "id"));
                    WorldTrainers.move(p, w);
                    Msg.send(p, "trainer.moved", "id", w.id);
                    return 1;
                })))
                .then(class_2170.method_9247("supprimer").then(class_2170.method_9244("id", StringArgumentType.word()).suggests(ids()).executes(c -> {
                    WorldTrainers.WorldTrainer w = WorldTrainers.get(StringArgumentType.getString(c, "id"));
                    if (w == null) {
                        Msg.send(c.getSource(), "trainer.unknown", "id", StringArgumentType.getString(c, "id"));
                        return 0;
                    }
                    WorldTrainers.remove(c.getSource().method_9211(), w);
                    Msg.send(c.getSource(), "trainer.deleted", "id", w.id);
                    return 1;
                })))
                .then(class_2170.method_9247("tp").then(class_2170.method_9244("id", StringArgumentType.word()).suggests(ids()).executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    WorldTrainers.WorldTrainer w = WorldTrainers.get(StringArgumentType.getString(c, "id"));
                    if (w == null || w.location == null) return unknown(p, StringArgumentType.getString(c, "id"));
                    w.location.teleport(p);
                    return 1;
                })))
                .then(class_2170.method_9247("reset").then(class_2170.method_9244("joueur", StringArgumentType.word())
                        .suggests((ctx, b) -> class_2172.method_9265(PlayerStore.names(), b))
                        .executes(c -> reset(c, null))
                        .then(class_2170.method_9244("id", StringArgumentType.word()).suggests(ids()).executes(c -> reset(c, StringArgumentType.getString(c, "id"))))));
        d.register(root);
    }

    private static int unknown(class_3222 p, String id) {
        Msg.send(p, "trainer.unknown", "id", id);
        return 0;
    }

    private static int edit(CommandContext<class_2168> c, String id) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        class_3222 p = c.getSource().method_9207();
        if (id == null) {
            NPCEntity npc = lookedAt(p);
            WorldTrainers.WorldTrainer w = npc == null ? null : WorldTrainers.of(npc);
            if (w == null) {
                Msg.send(p, "trainer.look_at_npc");
                return 0;
            }
            id = w.id;
        }
        EditorService.openWorld(p, id);
        return 1;
    }

    private static int reset(CommandContext<class_2168> c, String id) {
        String name = StringArgumentType.getString(c, "joueur");
        PlayerData d = PlayerStore.byName(name);
        if (d == null) {
            Msg.send(c.getSource(), "general.player_not_found", "player", name);
            return 0;
        }
        boolean ok = WorldTrainers.resetPlayer(d, id);
        Msg.send(c.getSource(), ok ? "trainer.reset_done" : "trainer.reset_nothing", "player", d.name, "id", id == null ? "*" : id);
        return ok ? 1 : 0;
    }

    static NPCEntity lookedAt(class_3222 p) {
        class_243 eye = p.method_33571();
        class_243 look = p.method_5828(1f);
        class_243 end = eye.method_1019(look.method_1021(8));
        class_238 box = p.method_5829().method_18804(look.method_1021(8)).method_1014(1);
        class_3966 hit = net.minecraft.class_1675.method_18075(p, eye, end, box,
                e -> e instanceof NPCEntity, 64);
        class_1297 e = hit == null ? null : hit.method_17782();
        return e instanceof NPCEntity n ? n : null;
    }
}
